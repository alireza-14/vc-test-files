# dataset description file

## speakers mapping
- f01: Leila Otadi
- m01: Mehran Modiri
- m02: Pejman Jamshidi
- m03: Hasan Roohani
- f02: Samaneh Pakdel
- m04: Soroush Sehat
- m05: Javad Zarif

